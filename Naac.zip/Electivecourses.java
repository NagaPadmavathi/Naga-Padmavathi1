import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ElectiveCourses")
public class ElectiveCourses extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            String url = "jdbc:mysql://localhost:3306/project";
            String username = "root";
            String password = "padma";
            Connection conn = DriverManager.getConnection(url, username, password);

            // Check column names
            DatabaseMetaData dbMetaData = conn.getMetaData();
            ResultSet columns = dbMetaData.getColumns(null, null, "electivecourses", null);
            while (columns.next()) {
                String columnName = columns.getString("COLUMN_NAME");
            }
            columns.close();

            // Adjusted Query to retrieve data
            String query = "SELECT * FROM electivecourses WHERE MyUnknownColumn LIKE 'OE%' OR MyUnknownColumn LIKE 'PE%'";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            // Pass the result set to the JSP file
            request.setAttribute("resultSet", resultSet);
            request.getRequestDispatcher("/jsp/Electivecourses.jsp").forward(request, response);

            // Close resources
            resultSet.close();
            preparedStatement.close();
            conn.close();
        } catch (Exception e) {
            response.getWriter().println("<html><body><h2>An error occurred</h2>");
            e.printStackTrace(response.getWriter());
            response.getWriter().println("</body></html>");
        }
    }
}
